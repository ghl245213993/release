# automatic
## 功能
- 在多个中继节点中负载均衡
- 自动进行节点可用性检测剔除不可用的中继节点（每个 30 秒，每次检查 3 次，超时为 10s）

## 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "ws",
                "remote": "azure-hk-a.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-b.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-c.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-d.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            }
        ],
        "mode": "automatic"
    }
]
```
```
0.0.0.0:443 → (azure-hk-a / azure-hk-b / azure-hk-c / azure-hk-d) → 1.1.1.1:443
```
