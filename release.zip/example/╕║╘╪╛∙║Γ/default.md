# default
## 功能
- 不带检测的 automatic

## 客户端
要啥配置文件，写个 default 就 wans 了