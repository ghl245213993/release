# fallback
## 功能
- 在一堆中继节点中筛选出一个可用的中继节点
- 从上往下，就算上面的死了，自动切下面的，如果上面的又恢复了，会切回去

## 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "ws",
                "remote": "azure-hk-a.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-b.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-c.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            },
            {
                "type": "ws",
                "remote": "azure-hk-d.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            }
        ],
        "mode": "fallback"
    }
]
```
```
0.0.0.0:443 → azure-hk-c → 1.1.1.1:443
```
