# Raw TLS
## 服务端
```json
[
    {
        "type": "rawtls",
        "listen": "0.0.0.0:443",
        "secret": "ignore|cristhebest",
        "method": "none",
        "options": "/etc/cuocuo/example.com.crt|/etc/cuocuo/example.com.key"
    }
]
```

## 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "rawtls",
                "remote": "remote.cutecr.moe:443",
                "secret": "ignore|cristhebest",
                "method": "none",
                "options": ""
            }
        ],
        "mode": "default"
    }
]
```
