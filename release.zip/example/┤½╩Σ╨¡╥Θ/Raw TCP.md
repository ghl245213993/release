# Raw TCP
## 服务端
```json
[
    {
        "type": "rawtcp",
        "listen": "0.0.0.0:10000",
        "secret": "ignore|cristhebest",
        "method": "chacha20-ietf",
        "options": ""
    }
]
```

## 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "rawtcp",
                "remote": "remote.cutecr.moe:10000",
                "secret": "ignore|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            }
        ],
        "mode": "default"
    }
]
```
