# WebSocket
## 不带 TLS
### 服务端
```json
[
    {
        "type": "ws",
        "listen": "0.0.0.0:80",
        "secret": "api/chat/websocket|cristhebest",
        "method": "chacha20-ietf",
        "options": ""
    }
]
```

### 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "ws",
                "remote": "remote.cutecr.moe:80",
                "secret": "api/chat/websocket|cristhebest",
                "method": "chacha20-ietf",
                "options": ""
            }
        ],
        "mode": "default"
    }
]
```

## 带 TLS
### 服务端
```json
[
    {
        "type": "wss",
        "listen": "0.0.0.0:443",
        "secret": "ignore|cristhebest",
        "method": "none",
        "options": "/etc/cuocuo/remote.sbxxd.com.crt|/etc/cuocuo/remote.sbxxd.com.key"
    }
]
```

### 客户端
```json
[
    {
        "rule": [
            {
                "listen_addr": "0.0.0.0",
                "listen_port": "443",
                "remote_addr": "1.1.1.1",
                "remote_port": "443",
                "mode": "tcp_and_udp"
            }
        ],
        "next": [
            {
                "type": "wss",
                "remote": "remote.cutecr.moe:443",
                "secret": "ignore|cristhebest",
                "method": "none",
                "options": ""
            }
        ],
        "mode": "default"
    }
]
```
